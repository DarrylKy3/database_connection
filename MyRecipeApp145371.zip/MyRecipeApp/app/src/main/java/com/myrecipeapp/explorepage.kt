package com.myrecipeapp

import android.os.Bundle
import android.widget.Button

class explorepage<T>(button1: Int) {

    private fun  onCreate(savedInstanceState: Bundle?) {
        this.onCreate(savedInstanceState)
        setContentView()
    }

    private fun setContentView() {

    }
    val button1 = explorepage<Button>(R.id.button1)
    val button2 = explorepage<Any>(R.id.button2)

    button1.setOnClickListener {

        val intent = startActivity(this, biryani::class.java)
        startActivity(biryani)
    }
    button2.setOnClickListener {

        val injera = Intent(this, injera::class.java)
        startActivity(injera)
    }

}



