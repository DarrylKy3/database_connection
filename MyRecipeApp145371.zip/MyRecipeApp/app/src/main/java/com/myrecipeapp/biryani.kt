package com.myrecipeapp

class biryani {
}